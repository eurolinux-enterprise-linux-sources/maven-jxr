package exclude;

/**
 * An excluded class.
 */
public class ExcludedClass
{
}
