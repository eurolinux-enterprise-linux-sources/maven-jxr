package include;

/**
 * An included class.
 */
public class IncludedClass
{
}
