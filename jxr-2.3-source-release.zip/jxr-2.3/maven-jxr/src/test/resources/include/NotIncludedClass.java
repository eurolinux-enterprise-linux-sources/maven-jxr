package include;

/**
 * A class that is not included.
 */
public class NotIncludedClass
{
}
